function mostrarTitulo() {
	document.getElementById("idCurso").addEventListener("change", function() {
		var idCurso = this.value;
		var tituloCurso;

		switch (idCurso) {
			case "1":
				tituloCurso = "Matemáticas";
				break;
			case "2":
				tituloCurso = "Historia";
				break;
			case "3":
				tituloCurso = "Inglés";
				break;
			case "4":
				tituloCurso = "Física";
				break;
			case "5":
				tituloCurso = "Química";
				break;
			case "6":
				tituloCurso = "Literatura";
				break;
			case "7":
				tituloCurso = "Biología";
				break;
			case "8":
				tituloCurso = "Geografía";
				break;
			case "9":
				tituloCurso = "Arte";
				break;
			case "10":
				tituloCurso = "Música";
				break;
			default:
				tituloCurso = "Curso Desconocido";
		}

            document.getElementById("tituloCurso").value = tituloCurso;
        });
}


